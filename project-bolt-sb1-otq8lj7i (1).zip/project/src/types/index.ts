export interface Student {
  id: string;
  student_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  date_of_birth: string;
  address: string;
  enrollment_date: string;
  class_year: string;
  major: string;
  status: 'active' | 'inactive' | 'graduated';
  created_at: string;
}

export interface FeeStructure {
  id: string;
  name: string;
  amount: number;
  category: 'tuition' | 'library' | 'lab' | 'sports' | 'transport' | 'other';
  class_year: string;
  due_date: string;
  is_mandatory: boolean;
  created_at: string;
}

export interface FeePayment {
  id: string;
  student_id: string;
  fee_structure_id: string;
  amount_paid: number;
  payment_date: string;
  payment_method: 'cash' | 'card' | 'bank_transfer' | 'online';
  status: 'paid' | 'pending' | 'overdue';
  created_at: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  credits: number;
  class_year: string;
  created_at: string;
}

export interface Mark {
  id: string;
  student_id: string;
  subject_id: string;
  exam_type: 'midterm' | 'final' | 'quiz' | 'assignment' | 'project';
  marks_obtained: number;
  total_marks: number;
  exam_date: string;
  created_at: string;
}

export interface DashboardStats {
  totalStudents: number;
  activeStudents: number;
  totalFees: number;
  paidFees: number;
  pendingFees: number;
  averageMarks: number;
}