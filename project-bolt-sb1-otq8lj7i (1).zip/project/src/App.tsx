import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Students from './components/Students';
import FeeManagement from './components/FeeManagement';
import MarksManagement from './components/MarksManagement';
import Reports from './components/Reports';
import type { 
  Student, 
  FeeStructure, 
  FeePayment, 
  Mark, 
  Subject, 
  DashboardStats 
} from './types';

// Mock data for demonstration
const mockStudents: Student[] = [
  {
    id: '1',
    student_id: 'STU001',
    first_name: 'John',
    last_name: 'Doe',
    email: 'john.doe@university.edu',
    phone: '+1-555-0123',
    date_of_birth: '2002-03-15',
    address: '123 Main St, Anytown, USA',
    enrollment_date: '2023-09-01',
    class_year: 'Sophomore',
    major: 'Computer Science',
    status: 'active',
    created_at: '2023-09-01T00:00:00Z',
  },
  {
    id: '2',
    student_id: 'STU002',
    first_name: 'Jane',
    last_name: 'Smith',
    email: 'jane.smith@university.edu',
    phone: '+1-555-0124',
    date_of_birth: '2001-07-22',
    address: '456 Oak Ave, Somewhere, USA',
    enrollment_date: '2022-09-01',
    class_year: 'Junior',
    major: 'Mathematics',
    status: 'active',
    created_at: '2022-09-01T00:00:00Z',
  },
];

const mockSubjects: Subject[] = [
  {
    id: '1',
    name: 'Introduction to Computer Science',
    code: 'CS101',
    credits: 3,
    class_year: 'Freshman',
    created_at: '2023-09-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'Calculus I',
    code: 'MATH101',
    credits: 4,
    class_year: 'Freshman',
    created_at: '2023-09-01T00:00:00Z',
  },
];

const mockFeeStructures: FeeStructure[] = [
  {
    id: '1',
    name: 'Tuition Fee - Fall 2024',
    amount: 15000,
    category: 'tuition',
    class_year: 'Sophomore',
    due_date: '2024-09-15',
    is_mandatory: true,
    created_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'Library Fee',
    amount: 200,
    category: 'library',
    class_year: 'Junior',
    due_date: '2024-10-01',
    is_mandatory: true,
    created_at: '2024-01-01T00:00:00Z',
  },
];

const mockFeePayments: FeePayment[] = [
  {
    id: '1',
    student_id: '1',
    fee_structure_id: '1',
    amount_paid: 15000,
    payment_date: '2024-09-10',
    payment_method: 'bank_transfer',
    status: 'paid',
    created_at: '2024-09-10T00:00:00Z',
  },
];

const mockMarks: Mark[] = [
  {
    id: '1',
    student_id: '1',
    subject_id: '1',
    exam_type: 'midterm',
    marks_obtained: 85,
    total_marks: 100,
    exam_date: '2024-10-15',
    created_at: '2024-10-15T00:00:00Z',
  },
  {
    id: '2',
    student_id: '2',
    subject_id: '2',
    exam_type: 'midterm',
    marks_obtained: 92,
    total_marks: 100,
    exam_date: '2024-10-16',
    created_at: '2024-10-16T00:00:00Z',
  },
];

function App() {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [students, setStudents] = useState<Student[]>(mockStudents);
  const [subjects, setSubjects] = useState<Subject[]>(mockSubjects);
  const [feeStructures, setFeeStructures] = useState<FeeStructure[]>(mockFeeStructures);
  const [feePayments, setFeePayments] = useState<FeePayment[]>(mockFeePayments);
  const [marks, setMarks] = useState<Mark[]>(mockMarks);

  // Calculate dashboard statistics
  const dashboardStats: DashboardStats = {
    totalStudents: students.length,
    activeStudents: students.filter(s => s.status === 'active').length,
    totalFees: feeStructures.reduce((sum, fee) => sum + fee.amount, 0),
    paidFees: feePayments
      .filter(p => p.status === 'paid')
      .reduce((sum, payment) => sum + payment.amount_paid, 0),
    pendingFees: feeStructures.reduce((sum, fee) => sum + fee.amount, 0) - 
      feePayments
        .filter(p => p.status === 'paid')
        .reduce((sum, payment) => sum + payment.amount_paid, 0),
    averageMarks: marks.length > 0 
      ? marks.reduce((sum, mark) => sum + (mark.marks_obtained / mark.total_marks) * 100, 0) / marks.length
      : 0,
  };

  // Handler functions
  const handleAddStudent = (studentData: Omit<Student, 'id' | 'created_at'>) => {
    const newStudent: Student = {
      ...studentData,
      id: uuidv4(),
      created_at: new Date().toISOString(),
    };
    setStudents(prev => [...prev, newStudent]);
  };

  const handleEditStudent = (id: string, studentData: Partial<Student>) => {
    setStudents(prev => prev.map(student => 
      student.id === id ? { ...student, ...studentData } : student
    ));
  };

  const handleDeleteStudent = (id: string) => {
    setStudents(prev => prev.filter(student => student.id !== id));
    // Also remove related marks and payments
    setMarks(prev => prev.filter(mark => mark.student_id !== id));
    setFeePayments(prev => prev.filter(payment => payment.student_id !== id));
  };

  const handleAddSubject = (subjectData: Omit<Subject, 'id' | 'created_at'>) => {
    const newSubject: Subject = {
      ...subjectData,
      id: uuidv4(),
      created_at: new Date().toISOString(),
    };
    setSubjects(prev => [...prev, newSubject]);
  };

  const handleAddFeeStructure = (feeData: Omit<FeeStructure, 'id' | 'created_at'>) => {
    const newFee: FeeStructure = {
      ...feeData,
      id: uuidv4(),
      created_at: new Date().toISOString(),
    };
    setFeeStructures(prev => [...prev, newFee]);
  };

  const handleRecordPayment = (paymentData: Omit<FeePayment, 'id' | 'created_at'>) => {
    const newPayment: FeePayment = {
      ...paymentData,
      id: uuidv4(),
      created_at: new Date().toISOString(),
    };
    setFeePayments(prev => [...prev, newPayment]);
  };

  const handleAddMark = (markData: Omit<Mark, 'id' | 'created_at'>) => {
    const newMark: Mark = {
      ...markData,
      id: uuidv4(),
      created_at: new Date().toISOString(),
    };
    setMarks(prev => [...prev, newMark]);
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard stats={dashboardStats} />;
      case 'students':
        return (
          <Students 
            students={students}
            onAddStudent={handleAddStudent}
            onEditStudent={handleEditStudent}
            onDeleteStudent={handleDeleteStudent}
          />
        );
      case 'fees':
        return (
          <FeeManagement 
            feeStructures={feeStructures}
            feePayments={feePayments}
            students={students}
            onAddFeeStructure={handleAddFeeStructure}
            onRecordPayment={handleRecordPayment}
          />
        );
      case 'marks':
        return (
          <MarksManagement 
            marks={marks}
            subjects={subjects}
            students={students}
            onAddMark={handleAddMark}
            onAddSubject={handleAddSubject}
          />
        );
      case 'reports':
        return (
          <Reports 
            students={students}
            feeStructures={feeStructures}
            feePayments={feePayments}
            marks={marks}
            subjects={subjects}
          />
        );
      case 'settings':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Settings</h3>
            <p className="text-gray-600">Settings panel coming soon...</p>
          </div>
        );
      default:
        return <Dashboard stats={dashboardStats} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <main className="ml-64 p-8">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;