import React, { useState } from 'react';
import { Plus, Search, BookOpen, TrendingUp, Award } from 'lucide-react';
import type { Mark, Subject, Student } from '../types';

interface MarksManagementProps {
  marks: Mark[];
  subjects: Subject[];
  students: Student[];
  onAddMark: (mark: Omit<Mark, 'id' | 'created_at'>) => void;
  onAddSubject: (subject: Omit<Subject, 'id' | 'created_at'>) => void;
}

const MarksManagement: React.FC<MarksManagementProps> = ({
  marks,
  subjects,
  students,
  onAddMark,
  onAddSubject,
}) => {
  const [activeTab, setActiveTab] = useState<'marks' | 'subjects'>('marks');
  const [showAddMarkForm, setShowAddMarkForm] = useState(false);
  const [showAddSubjectForm, setShowAddSubjectForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState('');

  const [markFormData, setMarkFormData] = useState({
    student_id: '',
    subject_id: '',
    exam_type: 'midterm' as const,
    marks_obtained: 0,
    total_marks: 100,
    exam_date: '',
  });

  const [subjectFormData, setSubjectFormData] = useState({
    name: '',
    code: '',
    credits: 3,
    class_year: '',
  });

  const handleMarkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddMark(markFormData);
    setMarkFormData({
      student_id: '',
      subject_id: '',
      exam_type: 'midterm',
      marks_obtained: 0,
      total_marks: 100,
      exam_date: '',
    });
    setShowAddMarkForm(false);
  };

  const handleSubjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddSubject(subjectFormData);
    setSubjectFormData({
      name: '',
      code: '',
      credits: 3,
      class_year: '',
    });
    setShowAddSubjectForm(false);
  };

  const getStudentName = (studentId: string) => {
    const student = students.find(s => s.id === studentId);
    return student ? `${student.first_name} ${student.last_name}` : 'Unknown Student';
  };

  const getSubjectName = (subjectId: string) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.name : 'Unknown Subject';
  };

  const getSubjectCode = (subjectId: string) => {
    const subject = subjects.find(s => s.id === subjectId);
    return subject ? subject.code : 'N/A';
  };

  const calculatePercentage = (obtained: number, total: number) => {
    return ((obtained / total) * 100).toFixed(1);
  };

  const getGrade = (percentage: number) => {
    if (percentage >= 90) return { grade: 'A+', color: 'text-emerald-600' };
    if (percentage >= 80) return { grade: 'A', color: 'text-emerald-600' };
    if (percentage >= 70) return { grade: 'B+', color: 'text-blue-600' };
    if (percentage >= 60) return { grade: 'B', color: 'text-blue-600' };
    if (percentage >= 50) return { grade: 'C', color: 'text-orange-600' };
    return { grade: 'F', color: 'text-red-600' };
  };

  const filteredMarks = marks.filter(mark => {
    const student = students.find(s => s.id === mark.student_id);
    const subject = subjects.find(s => s.id === mark.subject_id);
    const studentName = student ? `${student.first_name} ${student.last_name}` : '';
    const subjectName = subject ? subject.name : '';
    
    const matchesSearch = studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         subjectName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStudent = selectedStudent === '' || mark.student_id === selectedStudent;
    
    return matchesSearch && matchesStudent;
  });

  const filteredSubjects = subjects.filter(subject =>
    subject.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    subject.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getExamTypeColor = (examType: string) => {
    const colors = {
      midterm: 'bg-blue-100 text-blue-800',
      final: 'bg-purple-100 text-purple-800',
      quiz: 'bg-emerald-100 text-emerald-800',
      assignment: 'bg-orange-100 text-orange-800',
      project: 'bg-indigo-100 text-indigo-800',
    };
    return colors[examType as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  // Calculate student statistics
  const getStudentStats = (studentId: string) => {
    const studentMarks = marks.filter(m => m.student_id === studentId);
    if (studentMarks.length === 0) return null;

    const totalPercentage = studentMarks.reduce((sum, mark) => {
      return sum + (mark.marks_obtained / mark.total_marks) * 100;
    }, 0);

    const averagePercentage = totalPercentage / studentMarks.length;
    const { grade } = getGrade(averagePercentage);

    return {
      averagePercentage: averagePercentage.toFixed(1),
      grade,
      totalExams: studentMarks.length,
    };
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Marks & Grades</h2>
        <div className="flex space-x-3">
          <button
            onClick={() => setShowAddSubjectForm(true)}
            className="bg-gradient-to-r from-violet-600 to-purple-600 text-white px-6 py-3 rounded-xl flex items-center space-x-2 hover:from-violet-700 hover:to-purple-700 hover:scale-105 transition-all duration-300 shadow-lg"
          >
            <BookOpen size={20} />
            <span>Add Subject</span>
          </button>
          <button
            onClick={() => setShowAddMarkForm(true)}
            className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white px-6 py-3 rounded-xl flex items-center space-x-2 hover:from-cyan-700 hover:to-blue-700 hover:scale-105 transition-all duration-300 shadow-lg"
          >
            <Plus size={20} />
            <span>Add Marks</span>
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-gradient-to-r from-white via-green-50 to-emerald-50 rounded-xl shadow-lg border border-emerald-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('marks')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'marks'
                  ? 'border-emerald-500 text-emerald-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Student Marks
            </button>
            <button
              onClick={() => setActiveTab('subjects')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'subjects'
                  ? 'border-emerald-500 text-emerald-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Subjects
            </button>
          </nav>
        </div>

        <div className="p-6">
          {/* Search and Filter */}
          <div className="mb-6 flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder={activeTab === 'marks' ? 'Search by student or subject...' : 'Search subjects...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            {activeTab === 'marks' && (
              <select
                value={selectedStudent}
                onChange={(e) => setSelectedStudent(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">All Students</option>
                {students.map((student) => (
                  <option key={student.id} value={student.id}>
                    {student.first_name} {student.last_name}
                  </option>
                ))}
              </select>
            )}
          </div>

          {activeTab === 'marks' && (
            <div className="space-y-6">
              {/* Student Performance Overview */}
              {selectedStudent && (
                <div className="bg-gradient-to-r from-purple-100 via-pink-100 to-red-100 rounded-xl p-6 border border-purple-300 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {getStudentName(selectedStudent)}
                      </h3>
                      <p className="text-sm text-gray-600">Performance Overview</p>
                    </div>
                    {(() => {
                      const stats = getStudentStats(selectedStudent);
                      if (!stats) return null;
                      const { grade } = getGrade(parseFloat(stats.averagePercentage));
                      return (
                        <div className="text-right">
                          <div className="flex items-center space-x-4">
                            <div>
                              <p className="text-2xl font-bold text-gray-900">{stats.averagePercentage}%</p>
                              <p className="text-sm text-gray-600">Average</p>
                            </div>
                            <div>
                              <p className={`text-2xl font-bold ${getGrade(parseFloat(stats.averagePercentage)).color}`}>
                                {grade}
                              </p>
                              <p className="text-sm text-gray-600">Grade</p>
                            </div>
                            <div>
                              <p className="text-2xl font-bold text-gray-900">{stats.totalExams}</p>
                              <p className="text-sm text-gray-600">Exams</p>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </div>
              )}

              {/* Marks Table */}
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Student
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Subject
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Exam Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Marks
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Percentage
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Grade
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredMarks.map((mark) => {
                      const percentage = parseFloat(calculatePercentage(mark.marks_obtained, mark.total_marks));
                      const { grade, color } = getGrade(percentage);
                      return (
                        <tr key={mark.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {getStudentName(mark.student_id)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <div>
                              <div className="font-medium">{getSubjectName(mark.subject_id)}</div>
                              <div className="text-xs text-gray-400">{getSubjectCode(mark.subject_id)}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getExamTypeColor(mark.exam_type)}`}>
                              {mark.exam_type.charAt(0).toUpperCase() + mark.exam_type.slice(1)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                            {mark.marks_obtained}/{mark.total_marks}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                            {percentage}%
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`text-lg font-bold ${color}`}>{grade}</span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(mark.exam_date).toLocaleDateString()}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'subjects' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSubjects.map((subject) => (
                <div key={subject.id} className="bg-gradient-to-br from-white via-teal-50 to-cyan-50 border border-teal-200 rounded-xl p-6 hover:shadow-xl hover:scale-105 transition-all duration-300 shadow-lg">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{subject.name}</h3>
                      <p className="text-sm text-gray-600">Code: {subject.code}</p>
                    </div>
                    <div className="bg-gradient-to-r from-teal-500 to-cyan-500 text-white px-3 py-1 rounded-full text-xs font-medium shadow-sm">
                      {subject.credits} Credits
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Class:</span>
                      <span className="font-medium">{subject.class_year}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Total Students:</span>
                      <span className="font-medium">
                        {marks.filter(m => m.subject_id === subject.id).length > 0 
                          ? new Set(marks.filter(m => m.subject_id === subject.id).map(m => m.student_id)).size
                          : 0}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Avg Score:</span>
                      <span className="font-medium">
                        {(() => {
                          const subjectMarks = marks.filter(m => m.subject_id === subject.id);
                          if (subjectMarks.length === 0) return 'N/A';
                          const avg = subjectMarks.reduce((sum, mark) => 
                            sum + (mark.marks_obtained / mark.total_marks) * 100, 0
                          ) / subjectMarks.length;
                          return `${avg.toFixed(1)}%`;
                        })()}
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <BookOpen size={16} />
                      <span>Added {new Date(subject.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add Mark Modal */}
      {showAddMarkForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Add Marks</h3>
            </div>

            <form onSubmit={handleMarkSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Student</label>
                <select
                  required
                  value={markFormData.student_id}
                  onChange={(e) => setMarkFormData({ ...markFormData, student_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Student</option>
                  {students.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.first_name} {student.last_name} - {student.student_id}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                <select
                  required
                  value={markFormData.subject_id}
                  onChange={(e) => setMarkFormData({ ...markFormData, subject_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Subject</option>
                  {subjects.map((subject) => (
                    <option key={subject.id} value={subject.id}>
                      {subject.name} ({subject.code})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Exam Type</label>
                  <select
                    value={markFormData.exam_type}
                    onChange={(e) => setMarkFormData({ ...markFormData, exam_type: e.target.value as any })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="midterm">Midterm</option>
                    <option value="final">Final</option>
                    <option value="quiz">Quiz</option>
                    <option value="assignment">Assignment</option>
                    <option value="project">Project</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Exam Date</label>
                  <input
                    type="date"
                    required
                    value={markFormData.exam_date}
                    onChange={(e) => setMarkFormData({ ...markFormData, exam_date: e.target.value })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Marks Obtained</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={markFormData.marks_obtained}
                    onChange={(e) => setMarkFormData({ ...markFormData, marks_obtained: parseInt(e.target.value) })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Total Marks</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={markFormData.total_marks}
                    onChange={(e) => setMarkFormData({ ...markFormData, total_marks: parseInt(e.target.value) })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              {markFormData.marks_obtained > 0 && markFormData.total_marks > 0 && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">Percentage:</span>
                    <span className="text-lg font-bold text-blue-600">
                      {calculatePercentage(markFormData.marks_obtained, markFormData.total_marks)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm font-medium text-gray-700">Grade:</span>
                    <span className={`text-lg font-bold ${getGrade(parseFloat(calculatePercentage(markFormData.marks_obtained, markFormData.total_marks))).color}`}>
                      {getGrade(parseFloat(calculatePercentage(markFormData.marks_obtained, markFormData.total_marks))).grade}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                >
                  Add Marks
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddMarkForm(false)}
                  className="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors duration-200"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Subject Modal */}
      {showAddSubjectForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Add Subject</h3>
            </div>

            <form onSubmit={handleSubjectSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Subject Name</label>
                <input
                  type="text"
                  required
                  value={subjectFormData.name}
                  onChange={(e) => setSubjectFormData({ ...subjectFormData, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Subject Code</label>
                  <input
                    type="text"
                    required
                    value={subjectFormData.code}
                    onChange={(e) => setSubjectFormData({ ...subjectFormData, code: e.target.value })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Credits</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="6"
                    value={subjectFormData.credits}
                    onChange={(e) => setSubjectFormData({ ...subjectFormData, credits: parseInt(e.target.value) })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Class Year</label>
                <select
                  required
                  value={subjectFormData.class_year}
                  onChange={(e) => setSubjectFormData({ ...subjectFormData, class_year: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select Class</option>
                  <option value="Freshman">Freshman</option>
                  <option value="Sophomore">Sophomore</option>
                  <option value="Junior">Junior</option>
                  <option value="Senior">Senior</option>
                </select>
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors duration-200"
                >
                  Add Subject
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddSubjectForm(false)}
                  className="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors duration-200"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MarksManagement;