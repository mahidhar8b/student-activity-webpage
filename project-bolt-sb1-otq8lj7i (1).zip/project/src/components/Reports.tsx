import React, { useState } from 'react';
import { BarChart3, Users, DollarSign, TrendingUp, Download, Calendar } from 'lucide-react';
import type { Student, FeeStructure, FeePayment, Mark, Subject } from '../types';

interface ReportsProps {
  students: Student[];
  feeStructures: FeeStructure[];
  feePayments: FeePayment[];
  marks: Mark[];
  subjects: Subject[];
}

const Reports: React.FC<ReportsProps> = ({
  students,
  feeStructures,
  feePayments,
  marks,
  subjects,
}) => {
  const [selectedReport, setSelectedReport] = useState<'overview' | 'academic' | 'financial'>('overview');
  const [dateRange, setDateRange] = useState({
    start: '',
    end: '',
  });

  // Calculate overview statistics
  const overviewStats = {
    totalStudents: students.length,
    activeStudents: students.filter(s => s.status === 'active').length,
    totalSubjects: subjects.length,
    totalExams: marks.length,
    totalFees: feeStructures.reduce((sum, fee) => sum + fee.amount, 0),
    collectedFees: feePayments
      .filter(p => p.status === 'paid')
      .reduce((sum, payment) => sum + payment.amount_paid, 0),
    pendingFees: feePayments
      .filter(p => p.status === 'pending')
      .reduce((sum, payment) => sum + payment.amount_paid, 0),
  };

  // Calculate academic performance by class
  const academicPerformance = subjects.map(subject => {
    const subjectMarks = marks.filter(m => m.subject_id === subject.id);
    if (subjectMarks.length === 0) return null;

    const averagePercentage = subjectMarks.reduce((sum, mark) => {
      return sum + (mark.marks_obtained / mark.total_marks) * 100;
    }, 0) / subjectMarks.length;

    const gradeDistribution = subjectMarks.reduce((acc, mark) => {
      const percentage = (mark.marks_obtained / mark.total_marks) * 100;
      let grade = 'F';
      if (percentage >= 90) grade = 'A+';
      else if (percentage >= 80) grade = 'A';
      else if (percentage >= 70) grade = 'B+';
      else if (percentage >= 60) grade = 'B';
      else if (percentage >= 50) grade = 'C';

      acc[grade] = (acc[grade] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      subject: subject.name,
      code: subject.code,
      credits: subject.credits,
      classYear: subject.class_year,
      averagePercentage: averagePercentage.toFixed(1),
      totalStudents: new Set(subjectMarks.map(m => m.student_id)).size,
      gradeDistribution,
    };
  }).filter(Boolean);

  // Calculate fee collection by category
  const feeCollectionByCategory = feeStructures.reduce((acc, fee) => {
    const payments = feePayments.filter(p => p.fee_structure_id === fee.id);
    const collected = payments
      .filter(p => p.status === 'paid')
      .reduce((sum, p) => sum + p.amount_paid, 0);
    const pending = payments
      .filter(p => p.status === 'pending')
      .reduce((sum, p) => sum + p.amount_paid, 0);

    if (!acc[fee.category]) {
      acc[fee.category] = { total: 0, collected: 0, pending: 0 };
    }

    acc[fee.category].total += fee.amount;
    acc[fee.category].collected += collected;
    acc[fee.category].pending += pending;

    return acc;
  }, {} as Record<string, { total: number; collected: number; pending: number }>);

  // Calculate monthly fee collection trend
  const monthlyTrend = feePayments
    .filter(p => p.status === 'paid')
    .reduce((acc, payment) => {
      const month = new Date(payment.payment_date).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short' 
      });
      acc[month] = (acc[month] || 0) + payment.amount_paid;
      return acc;
    }, {} as Record<string, number>);

  const handleExportReport = () => {
    // In a real application, this would generate and download a PDF or Excel file
    const reportData = {
      overview: overviewStats,
      academic: academicPerformance,
      financial: feeCollectionByCategory,
      trend: monthlyTrend,
      generatedAt: new Date().toISOString(),
    };

    const dataStr = JSON.stringify(reportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `student-records-report-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Reports</h2>
        <button
          onClick={handleExportReport}
          className="bg-emerald-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-emerald-700 transition-colors duration-200"
        >
          <Download size={20} />
          <span>Export Report</span>
        </button>
      </div>

      {/* Report Type Selection */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setSelectedReport('overview')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                selectedReport === 'overview'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setSelectedReport('academic')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                selectedReport === 'academic'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Academic Performance
            </button>
            <button
              onClick={() => setSelectedReport('financial')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                selectedReport === 'financial'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Financial Reports
            </button>
          </nav>
        </div>

        <div className="p-6">
          {selectedReport === 'overview' && (
            <div className="space-y-6">
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100">Total Students</p>
                      <p className="text-3xl font-bold">{overviewStats.totalStudents}</p>
                    </div>
                    <Users className="w-8 h-8 text-blue-200" />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-xl p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-emerald-100">Active Students</p>
                      <p className="text-3xl font-bold">{overviewStats.activeStudents}</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-emerald-200" />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100">Total Subjects</p>
                      <p className="text-3xl font-bold">{overviewStats.totalSubjects}</p>
                    </div>
                    <BarChart3 className="w-8 h-8 text-purple-200" />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-orange-100">Fees Collected</p>
                      <p className="text-3xl font-bold">${overviewStats.collectedFees.toLocaleString()}</p>
                    </div>
                    <DollarSign className="w-8 h-8 text-orange-200" />
                  </div>
                </div>
              </div>

              {/* Monthly Trend */}
              <div className="bg-white border border-gray-200 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Fee Collection Trend</h3>
                <div className="space-y-4">
                  {Object.entries(monthlyTrend).map(([month, amount]) => (
                    <div key={month} className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">{month}</span>
                      <div className="flex items-center space-x-4">
                        <div className="bg-gray-200 rounded-full h-2 w-32">
                          <div 
                            className="bg-blue-500 rounded-full h-2 transition-all duration-300"
                            style={{ 
                              width: `${Math.min((amount / Math.max(...Object.values(monthlyTrend))) * 100, 100)}%` 
                            }}
                          ></div>
                        </div>
                        <span className="font-semibold text-gray-900">${amount.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {selectedReport === 'academic' && (
            <div className="space-y-6">
              <div className="bg-white border border-gray-200 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Subject Performance Overview</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Subject
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Code
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Class
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Students
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Average
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Grade Distribution
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {academicPerformance.map((subject, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {subject?.subject}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {subject?.code}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {subject?.classYear}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {subject?.totalStudents}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                            {subject?.averagePercentage}%
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <div className="flex space-x-1">
                              {Object.entries(subject?.gradeDistribution || {}).map(([grade, count]) => (
                                <span
                                  key={grade}
                                  className={`px-2 py-1 rounded text-xs font-medium ${
                                    grade.includes('A') ? 'bg-emerald-100 text-emerald-800' :
                                    grade.includes('B') ? 'bg-blue-100 text-blue-800' :
                                    grade.includes('C') ? 'bg-orange-100 text-orange-800' :
                                    'bg-red-100 text-red-800'
                                  }`}
                                >
                                  {grade}: {count}
                                </span>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {selectedReport === 'financial' && (
            <div className="space-y-6">
              <div className="bg-white border border-gray-200 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Fee Collection by Category</h3>
                <div className="space-y-4">
                  {Object.entries(feeCollectionByCategory).map(([category, data]) => (
                    <div key={category} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-md font-semibold text-gray-900 capitalize">{category}</h4>
                        <span className="text-sm text-gray-600">
                          {((data.collected / data.total) * 100).toFixed(1)}% collected
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 mb-3">
                        <div>
                          <p className="text-xs text-gray-600">Total</p>
                          <p className="text-lg font-semibold text-gray-900">${data.total.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600">Collected</p>
                          <p className="text-lg font-semibold text-emerald-600">${data.collected.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600">Pending</p>
                          <p className="text-lg font-semibold text-orange-600">${data.pending.toLocaleString()}</p>
                        </div>
                      </div>
                      
                      <div className="bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-emerald-500 rounded-full h-2 transition-all duration-300"
                          style={{ width: `${(data.collected / data.total) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Payment Summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-emerald-800">Total Collected</p>
                      <p className="text-2xl font-bold text-emerald-900">${overviewStats.collectedFees.toLocaleString()}</p>
                    </div>
                    <DollarSign className="w-8 h-8 text-emerald-600" />
                  </div>
                </div>

                <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-orange-800">Pending</p>
                      <p className="text-2xl font-bold text-orange-900">${overviewStats.pendingFees.toLocaleString()}</p>
                    </div>
                    <Calendar className="w-8 h-8 text-orange-600" />
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-800">Collection Rate</p>
                      <p className="text-2xl font-bold text-blue-900">
                        {overviewStats.totalFees > 0 
                          ? ((overviewStats.collectedFees / overviewStats.totalFees) * 100).toFixed(1)
                          : 0}%
                      </p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-blue-600" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Reports;