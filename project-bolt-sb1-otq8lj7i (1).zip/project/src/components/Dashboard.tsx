import React from 'react';
import { Users, DollarSign, TrendingUp, BookOpen, AlertCircle, CheckCircle } from 'lucide-react';
import type { DashboardStats } from '../types';

interface DashboardProps {
  stats: DashboardStats;
}

const Dashboard: React.FC<DashboardProps> = ({ stats }) => {
  const statCards = [
    {
      title: 'Total Students',
      value: stats.totalStudents,
      icon: Users,
      color: 'from-purple-500 via-pink-500 to-red-500',
      textColor: 'text-white',
      bgColor: 'bg-white/20',
    },
    {
      title: 'Active Students',
      value: stats.activeStudents,
      icon: CheckCircle,
      color: 'from-emerald-400 via-teal-500 to-blue-500',
      textColor: 'text-white',
      bgColor: 'bg-white/20',
    },
    {
      title: 'Total Fees Collected',
      value: `$${stats.paidFees.toLocaleString()}`,
      icon: DollarSign,
      color: 'from-yellow-400 via-orange-500 to-red-500',
      textColor: 'text-white',
      bgColor: 'bg-white/20',
    },
    {
      title: 'Average Marks',
      value: `${stats.averageMarks.toFixed(1)}%`,
      icon: TrendingUp,
      color: 'from-indigo-500 via-purple-500 to-pink-500',
      textColor: 'text-white',
      bgColor: 'bg-white/20',
    },
  ];

  const recentActivities = [
    { action: 'New student enrolled', student: 'John Doe', time: '2 hours ago', type: 'success' },
    { action: 'Fee payment received', student: 'Jane Smith', time: '4 hours ago', type: 'success' },
    { action: 'Overdue fee reminder', student: 'Mike Johnson', time: '6 hours ago', type: 'warning' },
    { action: 'Marks updated', student: 'Sarah Wilson', time: '1 day ago', type: 'info' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
        <div className="text-sm text-gray-500">
          Last updated: {new Date().toLocaleString()}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className={`bg-gradient-to-br ${stat.color} rounded-xl shadow-lg p-6 hover:shadow-2xl hover:scale-105 transition-all duration-300 text-white`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-white/80">{stat.title}</p>
                  <p className="text-3xl font-bold text-white mt-2">{stat.value}</p>
                </div>
                <div className={`${stat.bgColor} p-3 rounded-xl backdrop-blur-sm`}>
                  <Icon className={`w-8 h-8 ${stat.textColor}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fee Collection Overview */}
        <div className="bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-100 rounded-xl shadow-lg border border-blue-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Fee Collection Overview</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Total Fees</span>
              <span className="font-semibold">${stats.totalFees.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Collected</span>
              <span className="font-semibold text-emerald-600">${stats.paidFees.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Pending</span>
              <span className="font-semibold text-orange-600">${stats.pendingFees.toLocaleString()}</span>
            </div>
            <div className="mt-4">
              <div className="bg-gradient-to-r from-gray-200 to-gray-300 rounded-full h-3 shadow-inner">
                <div 
                  className="bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full h-3 transition-all duration-500 shadow-sm"
                  style={{ width: `${(stats.paidFees / stats.totalFees) * 100}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                {((stats.paidFees / stats.totalFees) * 100).toFixed(1)}% collected
              </p>
            </div>
          </div>
        </div>

        {/* Recent Activities */}
        <div className="bg-gradient-to-br from-purple-50 via-pink-50 to-rose-100 rounded-xl shadow-lg border border-purple-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activities</h3>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className={`flex-shrink-0 w-2 h-2 rounded-full mt-2 ${
                  activity.type === 'success' ? 'bg-gradient-to-r from-emerald-400 to-teal-500' :
                  activity.type === 'warning' ? 'bg-gradient-to-r from-orange-400 to-red-500' :
                  'bg-gradient-to-r from-blue-400 to-indigo-500'
                }`}></div>
                <div className="flex-grow">
                  <p className="text-sm text-gray-900">{activity.action}</p>
                  <p className="text-xs text-gray-500">{activity.student} • {activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-gradient-to-br from-yellow-50 via-orange-50 to-red-100 rounded-xl shadow-lg border border-orange-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl p-4 hover:from-blue-600 hover:to-purple-700 hover:scale-105 transition-all duration-300 shadow-lg">
            <Users size={20} />
            <span className="font-medium">Add New Student</span>
          </button>
          <button className="flex items-center justify-center space-x-2 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl p-4 hover:from-emerald-600 hover:to-teal-700 hover:scale-105 transition-all duration-300 shadow-lg">
            <DollarSign size={20} />
            <span className="font-medium">Record Payment</span>
          </button>
          <button className="flex items-center justify-center space-x-2 bg-gradient-to-r from-pink-500 to-rose-600 text-white rounded-xl p-4 hover:from-pink-600 hover:to-rose-700 hover:scale-105 transition-all duration-300 shadow-lg">
            <BookOpen size={20} />
            <span className="font-medium">Add Marks</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;