import React from 'react';
import { Users, DollarSign, BookOpen, BarChart3, Settings, Home } from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeSection, onSectionChange }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'fees', label: 'Fee Management', icon: DollarSign },
    { id: 'marks', label: 'Marks & Grades', icon: BookOpen },
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="bg-gradient-to-b from-purple-600 via-blue-600 to-indigo-700 h-screen w-64 shadow-2xl fixed left-0 top-0 z-10">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-white">🎓 EduRecord</h1>
        <p className="text-sm text-purple-100 mt-1">Student Management</p>
      </div>
      
      <nav className="mt-6">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`w-full flex items-center px-6 py-3 text-left transition-colors duration-200 ${
                activeSection === item.id
                  ? 'bg-white/20 text-white border-r-4 border-yellow-400 shadow-lg backdrop-blur-sm'
                  : 'text-purple-100 hover:bg-white/10 hover:text-white hover:shadow-md'
              }`}
            >
              <Icon size={20} className={`mr-3 ${activeSection === item.id ? 'text-yellow-300' : ''}`} />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>
      
      <div className="absolute bottom-6 left-6 right-6">
        <div className="bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-xl p-4 text-white shadow-lg">
          <p className="text-sm font-semibold">🚀 Need Help?</p>
          <p className="text-xs opacity-90 mt-1">Contact support for assistance</p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;